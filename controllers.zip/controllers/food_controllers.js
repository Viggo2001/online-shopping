const Food = require('../models/food');

module.exports.getFood = (req, res) => {
    Food.find()               // returns an array of objects
        .then((result) => {
            res.render('index', { food: result, head:'All Blogs' });
        })
        .catch((err) => console.log(err));    
}

module.exports.getFoodID = (req, res) => {
    const id = req.params.id;

    Food.findById(id)   
        .then((result) => {
            res.render('details', { cartFood: result, head: 'Details' });
        })
        .catch((err) => {
            console.log(err);
        });
}

module.exports.addFood = (req, res) => {
    const FoodObj = new Food({
        title: 'Pie',
        ingredients: 'Steak, Kidney, Sauce',
        cost: 20,
        qty: 1
    });

    FoodObj.save()
        .then((result) => {
            res.redirect('/food');
        })
        .catch((err) => console.log(err));
}