const User = require('../models/users');

//Function to handle errors
let handleError = (err) => {
    // console.log(err.message, err.code);

    const errors = { email: '', password: '' };

    if (err.code === 11000) {
        errors['email'] = 'This email already exists';
        return errors;
    }

    if (err.message.includes('user validation failed')) {
        Object.values(err.errors).forEach(errorObject => {
            errors[errorObject.path] = errorObject.properties.message;
        });
    }

    return errors;
}

module.exports.login_get = (req, res) => {
    res.send('log in');
}

module.exports.signup_get = (req, res) => {
    res.send('register');
}

module.exports.signup_post = async (req, res) => {
    const { email, password } = req.body;

    try {
        const user = await User.create({ email, password });
        res.send(user);
    } catch(err) {
        let errors = handleError(err);
        res.send(errors);
    }
}

module.exports.login_post = (req, res) => {
    res.send('log in');
}