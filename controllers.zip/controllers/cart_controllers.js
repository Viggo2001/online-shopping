const Cart = require('../models/cart-items');

module.exports.getCart = (req, res) => {
    Cart.find()
        .then((result) => {
            res.render('cart', { cartDetails: result, head: 'Shopping Cart' });
        })
        .catch((err) => console.log(err));
}

module.exports.addToCart = (req, res) => {
    const cartItems = new Cart(req.body);

    cartItems.save()
        .then((result) => {
            res.redirect('/cart');
        })
        .catch((err) => console.log(err));
}

module.exports.deleteFromCart = (req, res) => {
    const id = req.params.id;

    Cart.findByIdAndDelete(id)
        .then((result) => {
            res.json({ redirect: '/cart' });
        })
        .catch((err) => console.log(err));
}