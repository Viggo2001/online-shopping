const { Router } = require('express');
const food_controller = require('../controllers/food_controllers');
const router = Router();

router.get('/food', food_controller.getFood );
router.get('/food/:id', food_controller.getFoodID );

// we will use this to add new items available
router.get('/food/add', food_controller.addFood );

module.exports = router;