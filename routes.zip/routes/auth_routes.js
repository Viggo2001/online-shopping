const { Router } = require('express');
const auth_controllers = require('../controllers/auth_controllers');
const router = Router();

router.get('/login', auth_controllers.login_get );
router.get('/signup', auth_controllers.signup_get );
router.post('/login', auth_controllers.login_post );
router.post('/signup', auth_controllers.signup_post );

module.exports = router;