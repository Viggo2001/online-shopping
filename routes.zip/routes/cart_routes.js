const { Router } = require('express');
const cart_controllers = require('../controllers/cart_controllers');
const router = Router();

router.get('/cart', cart_controllers.getCart );
router.post('/cart/add', cart_controllers.addToCart );
router.delete('/cart/:id', cart_controllers.deleteFromCart );

module.exports = router;